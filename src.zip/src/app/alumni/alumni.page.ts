import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alumni',
  templateUrl: './alumni.page.html',
  styleUrls: ['./alumni.page.scss'],
})
export class AlumniPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
