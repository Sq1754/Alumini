import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reunion',
  templateUrl: './reunion.page.html',
  styleUrls: ['./reunion.page.scss'],
})
export class ReunionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
